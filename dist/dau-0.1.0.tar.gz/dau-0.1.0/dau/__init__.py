default_app_config = 'dau.apps.DjangoAutoUserConfig'
